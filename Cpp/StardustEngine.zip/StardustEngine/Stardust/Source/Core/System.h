#pragma once
#include "Types.h"
#include <set>


class System
{
public:
	std::set<Entity> _entities;
};