#pragma once
#include "../../Core/System.h"
#include <chrono>
#include <ctime>

class GravitySystem : public System
{
public:
	void update();
};

