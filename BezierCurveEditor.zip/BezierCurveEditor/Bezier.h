#pragma once

#include <glm/glm.hpp>
#include <vector>

int fact(int i) {
	if (i == 0 || i == 1)
		return 1;
	else
		return
		i * fact(i - 1);
}

inline float B(int n, int i) { return (float)(fact(n) / (fact(i)*fact(n - i))); }

float Bernstein(int n, int i, float u) {
	return B(n, i) * pow(u, i) * pow(1 - u, n - i);
}

std::vector<glm::vec3> BezierCurveByBernstein(std::vector<glm::vec3> & controlPoints, long nbU) {
	std::vector<glm::vec3> output;
	int n = controlPoints.size() - 1;

	{
		glm::vec3 out = glm::vec3(0.0f, 0.0f,0.0f);

		for (int j = 0; j <= n; j++) {
			out += Bernstein(n, j, 0) * controlPoints.at(j);
		}
		output.push_back(glm::vec3(out.x, out.y, 0.0f));
	
	}

	for (int i = 1; i < nbU; i++) {
		float u = 1.0f*i / nbU;

		glm::vec3 out = glm::vec3(0.0f, 0.0f, 0.0f);

		for (int j = 0; j <= n; j++) {
			out += Bernstein(n, j, u) * controlPoints.at(j);
		}

		output.push_back(glm::vec3(out.x, out.y, 0.0f));
		output.push_back(glm::vec3(out.x, out.y, 0.0f));
	}

	{
		glm::vec3 out = glm::vec3(0.0f, 0.0f, 0.0f);

		for (int j = 0; j <= n; j++) {
			out += Bernstein(n, j, 1) * controlPoints.at(j);
		}
		output.push_back(glm::vec3(out.x, out.y, 0.0f));
	}

	return output;
}
