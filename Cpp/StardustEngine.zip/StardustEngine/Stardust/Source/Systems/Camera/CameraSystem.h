#pragma once
#include "../../Core/System.h"
#include "../../Camera.h"

class CameraSystem : public System
{
public:
	void update();
	void update2();
};