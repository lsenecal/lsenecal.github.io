#pragma once
#include "../Camera.h"

struct CameraComponent {
	Camera * camera;
};