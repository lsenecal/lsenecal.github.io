#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
using namespace std;

#include <stdlib.h>
#include <string.h>

#include <glad/glad.h>

#include "shader.hpp"

GLuint load_shaders(const char * vertex_file_path,const char * fragment_file_path){

  // Create the shaders

  unsigned int vs = glCreateShader(GL_VERTEX_SHADER);
  unsigned int fs = glCreateShader(GL_FRAGMENT_SHADER);

  //**********************/

  // Read the Vertex Shader code from the file
  std::string vertex_shader_code;
  std::ifstream vertex_shader_stream(vertex_file_path, std::ios::in);
  if(vertex_shader_stream.is_open()){
    std::stringstream sstr;
    sstr << vertex_shader_stream.rdbuf();
    vertex_shader_code = sstr.str();
    vertex_shader_stream.close();
  }else{
    printf("Impossible to open %s. Are you in the right directory ? Don't forget to read the FAQ !\n", vertex_file_path);
    getchar();
    return 0;
  }

  // Read the Fragment Shader code from the file
  std::string fragment_shader_code;
  std::ifstream fragment_shader_stream(fragment_file_path, std::ios::in);
  if(fragment_shader_stream.is_open()){
    std::stringstream sstr;
    sstr << fragment_shader_stream.rdbuf();
    fragment_shader_code = sstr.str();
    fragment_shader_stream.close();
  }

  GLint result = GL_FALSE;
  int info_log_length = 1024;

// Compile Vertex Shader
  
  printf("Compiling shader : %s\n", vertex_file_path);
  const char * vertex_source_pointer = vertex_shader_code.c_str();
  
  glShaderSource(vs, 1, &vertex_source_pointer, NULL);
  glCompileShader(vs);
  
  // Check Vertex Shader
  
  int success;
  char infoLogVS[1024];
  glGetShaderiv(vs, GL_COMPILE_STATUS, &success);
  if (!success)
    {
      glGetShaderInfoLog(vs, info_log_length, NULL, infoLogVS);
      std::cerr << "ERROR : " << infoLogVS << std::endl;
    }
  
  //**********************/
  
  // Compile Fragment Shader
  
  printf("Compiling shader : %s\n", fragment_file_path);
  const char * FragmentSourcePointer = fragment_shader_code.c_str();
  
  glShaderSource(fs, 1, &FragmentSourcePointer, NULL);
  glCompileShader(fs);
  
  // Check Fragment Shader
  
  char infoLogFS[1024];
  glGetShaderiv(fs, GL_COMPILE_STATUS, &success);
  if (!success)
    {
      glGetShaderInfoLog(fs, info_log_length, NULL, infoLogFS);
      std::cerr << "ERROR : " << infoLogFS << std::endl;
    }
  
  //**********************/
  
  // Link the program
  printf("Linking program\n");
  
  unsigned int program_ID = glCreateProgram();
  glAttachShader(program_ID, vs);
  glAttachShader(program_ID, fs);
  glLinkProgram(program_ID);
  
  // Check the program

  char infoLogP[1024];
  glGetProgramiv(program_ID, GL_LINK_STATUS, &success);
  if (!success)
    {
      glGetShaderInfoLog(fs, info_log_length, NULL, infoLogP);
      std::cerr << "ERROR : " << infoLogP << std::endl;
    }
  
  //**********************/ 
 
  //Detacher et supprimer
  
  glDeleteShader(vs);
  glDeleteShader(fs);
  
  //******************************/
  
  return program_ID;
}


