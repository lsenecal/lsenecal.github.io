#pragma once
#include <glm/glm.hpp>

struct Patch
{
	glm::vec3 * Position;
	glm::vec3 * Normal;
	glm::vec3 * Dimension;
};